# fyusdt_pay
魔方财务 USDT支付插件
插件放在/public/plugins/gateways/
创建目录fyusdt_pay
然后全部文件丢里面
详细查看
https://api.hjyusdt.com/
<br>
<img src="https://www.helloimg.com/images/2022/04/11/RtdUzz.jpg" alt="RtdUzz.jpg" border="0" />
